#include <stdio.h>

void main ()
 {
   char title[255] = "Jamsa's 1001 C & C++ Tips";

   printf("The name of this book is %s\n", title);
 }

