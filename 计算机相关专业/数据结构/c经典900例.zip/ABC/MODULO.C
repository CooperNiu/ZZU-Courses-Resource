#include <stdio.h>

void main ()
 {
   int remainder;
   int result;

   result = 10 / 3;
   remainder = 10 % 3;

   printf("10 Divided by 3 is %d Remainder %d\n",
     result, remainder);
 }

