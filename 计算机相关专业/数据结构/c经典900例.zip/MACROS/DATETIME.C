#include <stdio.h>

void main ()
 {
   printf("Beta Testing: Last compiled %s %s\n", __DATE__, 
     __TIME__);
 }
