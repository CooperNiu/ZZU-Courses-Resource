#include <stdio.h>

void main()
 {
   printf("1001 C & C++ Tips!);
 }

