#include <stdio.h>
#include <dos.h>

void main (void)
 {
    printf("About to delay 5 seconds\n");

    delay(5000);

    printf("Done\n");
 }



