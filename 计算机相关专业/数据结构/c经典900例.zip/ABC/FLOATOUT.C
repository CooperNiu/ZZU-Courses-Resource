#include <stdio.h>

void main ()
 {
   float price = 525.75;
   float sales_tax = 0.06; 

   printf("The item cost is %f\n", price);
   printf("Sales tax on the item is %f\n", price * sales_tax);
 }
