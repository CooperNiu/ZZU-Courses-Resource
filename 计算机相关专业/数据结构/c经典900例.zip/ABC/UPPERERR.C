#include <stdio.h>

Main ()
 {
   printf ("This program does not compile.");
 }
