#include<stdio.h>
#include<stdlib.h>
#include"library_management.h"
extern int state,current_index;

/*游客方式访问*/
void visitors(void) {
	int s = 0;
	while (state) {
		switch (visitor_menu()) {
		case '1':	search(about_book);			break;
		case '2':	s = 1;						break;
		case '3':	state = 0;					break;
		default:
			break;
		}
		if (s)	break;
	}
}

/*读者方式访问*/
void readers(void) {
	int s = 0;
	while (state) {
		switch (reader_menu()) {
		case '1':	search(about_book);			break;
		case '2':	search(about_history);		break;
		case '3':	book_borrow();				break;
		case '4':	book_return();				break;
		case '5':	search(about_user);			break;
		case '6':	modify(about_user);			break;
		case '7':	s = 1;						break;
		case '8':	state = 0;					break;
		default:
			break;
		}
		if (s)	break;
	}
}

/*管理员方式访问*/
void admins(void) {
	int s = 0;
	while (state) {
		switch (admin_menu()) {
		case '1':	search(about_book);			break;
		case '2':	search(about_history);		break;
		case '3':	book_borrow();				break;
		case '4':	book_return();				break;
		case '5':	search(about_user);			break;
		case '6':	modify(about_user);			break;
		case '7':	add(about_book);			break;
		case '8':	delete(about_book);			break;
		case '9':	modify(about_book);			break;
		case 'a':	s = 1;						break;
		case 'b':	state = 0;					break;
		default:
			break;
		}
		if (s)	break;
	}
}

/*超级管理员方式访问*/
void superadmins(void) {
	int s = 0;
	while (state) {
		switch (superadmin_menu()) {
		case '1':	search(about_book);		  		break;
		case '2':	search(about_history);			break;
		case '3':	book_borrow();			    	break;
		case '4':	book_return();				    break;
		case '5':	add(about_book);				break;
		case '6':	delete(about_book);				break;
		case '7':	modify(about_book);				break;
		case '8':	add(about_user);				break;
		case '9':	delete(about_user);				break;
		case 'a':	modify(about_user);				break;
		case 'b':	search(about_user);				break;
		case 'c':	admin_authoriza();				break;
		case 'd':	s = 1;							break;
		case 'e':	state = 0;						break;
		default:
			break;
		}
		if(s)	break;
				
	}
}
