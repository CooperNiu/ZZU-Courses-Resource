#include <stdio.h>

void main ()
 {
   int value = 0xFF;

   printf("The inverse of %X is %X\n", value, ~value);
 }
