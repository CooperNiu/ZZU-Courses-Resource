#include <stdlib.h>

void main (void)
 {
   if (system("DIR"))
     printf("Error invoking DIR\n");
 }

