#include <stdio.h>
#include <dos.h>

void main (void)
 {
   printf("The Program Segment Prefix begins at %X\n", _psp);
 }
