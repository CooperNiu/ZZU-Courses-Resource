#include <stdio.h>
#include <string.h>

void main(void)
 {
   char book_title[] = "Jamsa's 1001 C/C++ Tips";

   printf("%s contains %d characters\n",
    book_title, strlen(book_title));
 }

