#include <stdio.h>

void main ()
 {
   print ("This program does not link");
 }

