#include <stdio.h>

void main ()
 {
   printf ("This is line one.");
   printf ("This is the second line.");
 }

