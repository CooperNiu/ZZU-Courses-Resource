#include<stdio.h>
#include"library_management.h"
#pragma warning(disable : 4996)

User user[MAXN], *user_pointer[MAXN];
Book book[MAXN], *book_pointer[MAXN];
History history[MAXN*MAXN], *history_pointer[MAXN*MAXN];

int state,current_index;
int count_user = 0, count_book = 0, count_history = 0;

int main(void) {

	initial();
	welcome();
	while (state) {
		switch (authentication()) {
		case visitor:		visitors();		break;
		case reader:		readers();		break;
		case admin:		admins();		break;
		case superadmin:	superadmins();		break;
		case quit:		state = 0;		break;
		default:					break;
		}
	}
	save();	
	return 0;
}
