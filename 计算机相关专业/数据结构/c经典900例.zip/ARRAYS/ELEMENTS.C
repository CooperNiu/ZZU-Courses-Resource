#include <stdio.h>

void main(void)
 {
   int scores[5] = {80, 70, 90, 85, 80};

   printf("Array Values\n");
   printf("scores[0] %d\n", scores[0]);
   printf("scores[1] %d\n", scores[1]);
   printf("scores[2] %d\n", scores[2]);
   printf("scores[3] %d\n", scores[3]);
   printf("scores[4] %d\n", scores[4]);
 }
