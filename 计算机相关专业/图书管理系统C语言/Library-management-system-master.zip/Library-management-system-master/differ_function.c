#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include<time.h>
#include"library_management.h"
#pragma warning (disable : 4996)
extern User user[MAXN] ,*user_pointer[MAXN];
extern Book book[MAXN] ,*book_pointer[MAXN];
extern History history[MAXN*MAXN] ,*history_pointer[MAXN*MAXN];
extern int count_user, count_book, count_history,current_index;
char t_stuid[small];
char t_isbn[small];

/*
**	判断数组是否已满
**	若已满(最后不为“\n\0”) 则重置这两位
**	否则将‘\n’放回输入缓冲区
*/
void isfull(char *pointer, int size) {
	int len = strlen(pointer);
	
	if (len < size - 1 || (len == size - 1 && pointer[size - 2] == '\n') ){
		ungetc('\n', stdin);
	}
	else {
		pointer[size - 2] = '\n';
	}
}

/*刷新标准输入缓冲区*/
void flush_stdin(void) {
	int ch;
	while ((ch = getchar()) && ch != '\n' && ch != EOF) {
	}
}


/*  	
**
**	函数功能:	查询并打印数据(可查询多个不同的结构体) 
**  函数参数:    单个字符参数,char search_what 
**				用于说明查询的是什么数据
**				例如 若实参为 s_user, 代表查询的是用户信息; 
**				全部可能参数见头文件 library_management.h
*/
void search(char search_what) {
	system("cls");
	int count;
	if (search_what == about_user && user[current_index].identify[0] != superadmin) {
		echo(current_index, about_user);
		printf("\n\n\t请按任意键返回菜单..");
		getch();
	}
	else if (search_what == about_user) {
		User **pointer = user_pointer;
		printf("\n\n\t\t请输入读者学号: ");
		fgets(t_stuid, small, stdin);
		isfull(t_stuid, small);
		flush_stdin();
		count = 0;
		while (count < count_user) {
			if (!strcmp(pointer[count]->stuid, t_stuid)) {
				echo(count, about_user);
				printf("\n\n\t请按任意键返回主菜单..");
				getch();
				break;
			}
			++count;
		}
		if (count >= count_user) {
			printf("\n\n\t未查询到该用户!\n");
			printf("\n\n    ----------菜单----------\n\n");
			printf("\t1.重新输入学号\n");
			printf("\t2.返回主菜单\n");
			printf("\t请选择所需功能并输入其前序号<1-2>.");
			char ch;
			while ((ch = getch()) && (ch < '1' || ch > '2')) {
			};
			if (ch == '1')
				search(about_user);
		}
	}
	else if (search_what == about_book) {
		Book **pointer = book_pointer;
		printf("\n\n\t\t请输入ISBN: ");
		fgets(t_isbn, small, stdin);
		isfull(t_isbn, small);
		flush_stdin();
		count = 0;
		while (count < count_book) {
			if (!strcmp(pointer[count]->isbn, t_isbn)) {
				echo(count, about_book);
				printf("\n\n\t请按任意键返回菜单..");
				getch();
				break;
			}
			++count;
		}
		if (count >= count_book) {
			printf("\n\n\t未查询到该图书!\n");
			printf("\n\n    ----------菜单----------\n\n");
			printf("\t1.重新输入ISBN\n");
			printf("\t2.返回主菜单\n");
			printf("\t请选择所需功能并输入其前序号<1-2>.");
			char ch;
			while ((ch = getch()) && (ch < '1' || ch > '2')) {
			};
			if (ch == '1')
				search(about_book);
		}
	}
	else if (search_what == about_history) {
		printf("\n\n\t--------查询历史菜单--------\n\n");
		printf("\t1.查询指定读者记录.\n");
		printf("\t2.查询指定图书记录.\n");
		printf("\t3.查询指定读者对指定图书的记录\n");
		printf("\t请选择所需功能并输入其前序号<1-3>.");
		char ch;
		while ((ch = getch()) && !(ch >= '1' && ch <= '3'));
		switch (ch) {
		case '1':	sea_his_by_user();		break;
		case '2':	sea_his_by_book();		break;
		case '3':	sea_his_by_user_book();	break;
		default:							break;
		}
	}
}
/*查询指定读者记录*/
void sea_his_by_user(void) {
	system("cls");
	History **pointer = history_pointer;
	printf("\n\n\t\t请输入读者学号: ");
	fgets(t_stuid, small, stdin);
	isfull(t_stuid, small);
	flush_stdin();
	int count = 0,s=1;
	while (count < count_history) {
		if (!strcmp(pointer[count]->stuid, t_stuid)) {
			echo(count, about_history);
			s = 0;
		}
		++count;
	}
	if (s)	printf("\n\t未发现符合条件历史!\n");
	printf("\n\t请按任意键返回菜单..");
	getch();
}

/*查询指定图书记录*/
void sea_his_by_book(void){
	system("cls");
	History **pointer = history_pointer;
	printf("\n\n\t\t请输入ISBN: ");
	fgets(t_isbn, small, stdin);
	isfull(t_isbn, small);
	flush_stdin();
	int count = 0, s = 0;
	while (count < count_history) {
		if (!strcmp(pointer[count]->isbn, t_isbn)) {
			echo(count, about_history);
			s = 1;
		}
		++count;
	}
	if (s)
		printf("\n\t未发现符合条件历史!\n");
	printf("\n\t请按任意键返回菜单..");
	getch();
}

/*查询指定读者对指定图书的记录*/
void sea_his_by_user_book(void) {
	system("cls");
	History **pointer = history_pointer;
	printf("\n\n\t\t请输入读者学号: ");
	fgets(t_stuid, small, stdin);
	isfull(t_stuid, small);
	flush_stdin();
	printf("\n\t\t请输入ISBN: ");
	fgets(t_isbn, small, stdin);
	isfull(t_isbn, small);
	flush_stdin();
	int count = 0, s = 0;
	while (count < count_history) {
		if (!strcmp(pointer[count]->isbn, t_isbn) && !strcmp(pointer[count]->stuid, t_stuid)) {
			echo(count, about_history);
			s = 1;
		}
		++count;
	}
	if (s) 
		printf("\n\t未发现符合条件历史!\n");
	printf("\n\t请按任意键返回菜单..");
	getch();
}

/*
**	函数功能:	添加用户/图书/历史记录
**	函数参数:	说明添加的是什么
*/
void add(char add_what) {
	switch (add_what) {
	case about_user:	add_user();			break;
	case about_book:	add_book();			break;
	default:								break;
	}
}

/*添加历史*/
void add_history(Book *pointer) {
	strcpy(history[count_history].stuid, user[current_index].stuid);
	strcpy(history[count_history].name, pointer->name);
	strcpy(history[count_history].isbn, pointer->isbn);
	strcpy(history[count_history].author, pointer->author);
	strcpy(history[count_history].pub_date, pointer->pub_date);
	gettime(&history[count_history].borrow_time[0]);
	strcpy(history[count_history].return_time, "none\n");
	history[count_history].state = 1;
	++count_history;
}

/*获取当前时间并以1970-01-01形式储存在ti所指数组中*/
void gettime(char *ti) {
	time_t tt;
	struct tm *t;
	time(&tt);
	t = localtime(&tt);
	sprintf(ti, "%4d-%02d-%02d\n", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
}

/*添加用户*/
void add_user(void) {
	char ch;
	add_user_info();
	do {
		system("cls");
		echo(count_user, about_user);
		printf("\n\n\t温馨提示:\n");
		printf("\t\t所有项确认无误请输入<Y/y>,\n");
		printf("\t\t需修改请输入<N/n>.\n\n");
		ch = check();
		if (ch == 'y' || ch == 'Y')
			break;
		modify_user(show_modify_menu(about_user), count_user);
	} while (1);
	++count_user;
	system("cls");
	printf("\n\n\n\t\t添加成功!\n\n\t\t");
	system("pause");
}

/*检查输入是否符合要求*/
char check(void) {
	char ch;
	while ((ch = getch()) &&
		ch != 'Y' && ch != 'y' &&
		ch != 'n' && ch != 'N');
	return ch;
}

/*添加用户信息*/
void add_user_info(void) {
	system("cls");
	printf("\n\n\t请输入读者姓名: ");
	fgets(user[count_user].name, mid_b, stdin);
	isfull(user[count_user].name, mid_b);
	flush_stdin();
	printf("\t请输入读者年龄: ");
	fgets(user[count_user].age, 5, stdin);
	isfull(user[count_user].age, 5);
	flush_stdin();
	printf("\t请输入读者学号: ");
	fgets(user[count_user].stuid, small, stdin);
	isfull(user[count_user].stuid, small);
	flush_stdin();
	printf("\t请输入登录密码: ");
	fgets(user[count_user].password, mid_b, stdin);
	isfull(user[count_user].password, mid_b);
	flush_stdin();
	printf("\t请输入所属学院: ");
	fgets(user[count_user].college, mid_s, stdin);
	isfull(user[count_user].college, mid_s);
	flush_stdin();
	printf("\t请输入所属专业: ");
	fgets(user[count_user].major, small, stdin);
	isfull(user[count_user].major, small);
	flush_stdin();
	printf("\t请输入联系电话: ");
	fgets(user[count_user].phone, small, stdin);
	isfull(user[count_user].phone, small);
	flush_stdin();
	printf("\n\n    ----------赋予权限----------\n\n");
	printf("\t1.读者\n");
	printf("\t2.管理员\n");
	printf("\t3.超级管理员\n");
	printf("\t请选择所需功能并输入其前序号<1-3>.");
	fgets(user[count_user].identify, 5, stdin);
	isfull(user[count_user].identify, 5);
	flush_stdin();
	user[count_user].state = 1;
}

/*添加图书*/
void add_book(void) {
	char ch;
	add_book_info();
	do {
		system("cls");
		echo(count_book, about_book);
		printf("\n\n\t温馨提示:\n");
		printf("\t\t所有项确认无误请输入<Y/y>,\n");
		printf("\t\t需修改请输入<N/n>.\n\n");
		ch = check();
		if (ch == 'y' || ch == 'Y')
			break;
		modify_book(show_modify_menu(about_book),count_book);
	} while (1);
	system("cls");
	printf("\n\n\n\t\t添加成功!\n\n\t\t");
	++count_book;
	system("pause");
}

/*添加图书信息*/
void add_book_info(void) {
	system("cls");
	printf("\n\n\t请输入图书名称: ");
	fgets(book[count_book].name, big, stdin);
	isfull(book[count_book].name, big);
	flush_stdin();
	printf("\t请输入  ISBN  : ");
	fgets(book[count_book].isbn, small, stdin);
	isfull(book[count_book].isbn, small);
	flush_stdin();
	printf("\t请输入作    者: ");
	fgets(book[count_book].author, mid_b, stdin);
	isfull(book[count_book].author, mid_b);
	flush_stdin();
	printf("\t请输入出 版 社: ");
	fgets(book[count_book].press, mid_s, stdin);
	isfull(book[count_book].press, mid_s);
	flush_stdin();
	printf("\t请输入出版时间: ");
	fgets(book[count_book].pub_date, small, stdin);
	isfull(book[count_book].pub_date, small);
	flush_stdin();
	printf("\t请输入价    格: ");
	fgets(book[count_book].price, small, stdin);
	isfull(book[count_book].price, small);
	flush_stdin();
	printf("\t请输入馆藏总量: ");
	fgets(book[count_book].storage, 5, stdin);
	isfull(book[count_book].storage, 5);
	flush_stdin();
	book[count_book].state = 1;

}

/*回显用户/图书/历史记录信息*/
void echo(int index,char echo_what) {
	
	if (echo_what == about_user) {
		system("cls");
		User *pointer = user_pointer[index];
		printf("\n\n\t读者姓名: ");
		fputs(pointer->name, stdout);
		printf("\n\t读者年龄: ");
		fputs(pointer->age, stdout);
		printf("\n\t读者学号: ");
		fputs(pointer->stuid, stdout);
		printf("\n\t登录密码: ");
		fputs(pointer->password, stdout);
		printf("\n\t所属学院: ");
		fputs(pointer->college, stdout);
		printf("\n\t所属专业: ");
		fputs(pointer->major, stdout);
		printf("\n\t联系电话: ");
		fputs(pointer->phone, stdout);
		printf("\n\t权    限: ");
		switch (pointer->identify[0])
		{
		case reader:		printf("读者\n\t");			break;
		case admin:			printf("管理员\n\t");		break;
		case superadmin:	printf("超级管理员\n\t");	break;
		default:										break;
		}
	}
	else if (echo_what == about_book) {
		system("cls");
		Book *pointer = book_pointer[index];
		printf("\n\n\t图书名称: ");
		fputs(pointer->name, stdout);
		printf("\n\t图书ISBN: ");
		fputs(pointer->isbn, stdout);
		printf("\n\t作    者: ");
		fputs(pointer->author, stdout);
		printf("\n\t出 版 社: ");
		fputs(pointer->press, stdout);
		printf("\n\t出版时间: ");
		fputs(pointer->pub_date, stdout);
		printf("\n\t价    格: ");
		fputs(pointer->price, stdout);
		printf("\n\t馆藏总量: ");
		fputs(pointer->storage, stdout);
	}
	else if (echo_what == about_history) {
		History *pointer = history_pointer[index];
		printf("\n\n\t读者学号: ");
		fputs(pointer->stuid, stdout);
		printf("\t图书名称: ");
		fputs(pointer->name, stdout);
		printf("\t图书ISBN: ");
		fputs(pointer->isbn, stdout);
		printf("\t作    者: ");
		fputs(pointer->author, stdout);
		printf("\t出版时间: ");
		fputs(pointer->pub_date, stdout);
		printf("\t借出时间: ");
		fputs(pointer->borrow_time, stdout);
		printf("\t归还时间: ");
		fputs(pointer->return_time, stdout);
	}
	printf("\n\n");
}

/*
**	函数功能:	删除用户/图书/历史记录
**	函数参数:	说明删除的是什么
*/
void delete(char delete_what) {
	system("cls");
	int count;
	char ch;
	if (delete_what == about_user && user[current_index].identify[0] == superadmin) {
		count = 0;
		printf("\n\n\t\t请输入需删除用户的学号: ");
		fgets(t_stuid, small, stdin);
		isfull(t_stuid, small);
		flush_stdin();
		printf("\t\t");
		while (count < count_user) {
			if (!strcmp(user_pointer[count]->stuid, t_stuid)) {
				user_pointer[count]->state = 0;
				break;
			}
			++count;
		}	
		if (count == count_user) {
			printf("\n\n\t删除失败!");
			printf("\n\n    ----------菜单----------\n\n");
			printf("\t1.重新输入学号\n");
			printf("\t2.返回主菜单\n");
			printf("\t请选择所需功能并输入其前序号<1-2>.");
			while ((ch = getch()) && (ch < '1' || ch > '2')) {
			};
			if (ch == '1')
				delete(about_user);
		}
		else {
			printf("\n\t删除失败!\n");
			printf("\n\t请按任意键返回主菜单..");
			getch();
		}

	}
	else if (delete_what == about_book && user[current_index].identify[0] != reader) {
		count = 0;
		printf("\n\n\t\t请输入需删除图书的ISBN: ");
		fgets(t_stuid, small, stdin);
		isfull(t_stuid, small);
		flush_stdin();
		printf("\t\t");
		while (count < count_book) {
			if (!strcmp(book_pointer[count]->isbn, t_stuid)) {
				book_pointer[count]->state = 0;
				break;
			}
			++count;
		}
		if (count == count_book) {
			printf("\n\n\t删除失败!");
			printf("\n\n    ----------菜单----------\n\n");
			printf("\t1.重新输入ISBN\n");
			printf("\t2.返回主菜单\n");
			printf("\t请选择所需功能并输入其前序号<1-2>.");
			while ((ch = getch()) && (ch < '1' || ch > '2')) {
			};
			if (ch == '1')
				delete(about_book);
		}
		else {
			printf("\n\t删除成功!\n");
			printf("\n\t请按任意键返回主菜单..");
			getch();
		}

	}
	else if (delete_what == about_history ) {
		switch (delete_menu()) {
		case '1':	delete_by_user();		break;
		case '2':	delete_by_isbn();		break;
		case '3':	delete_by_isbn_user();	break;
		default:							break;
		}
	}
}

/*删除记录菜单*/
char delete_menu(void) {
	system("cls");
	printf("\n\n    ----------菜单----------\n\n");
	printf("\t1.以用户为单位删除历史\n");
	printf("\t2.以书为单位删除历史\n");
	printf("\t3.以用户及图书删除历史");
	printf("\t请选择所需功能并输入其前序号<1-3>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '3')) {
	};
	return ch;
}

/*以用户为单位删除历史记录*/
void delete_by_user(void) {
	system("cls");
	int count = 0, s = 1;
	printf("\t\t请输入对应用户学号: ");
	fgets(t_stuid, small, stdin);
	isfull(t_stuid, small);
	flush_stdin();
	printf("\t\t");
	while (count < count_history) {

		if (!strcmp(history_pointer[count]->stuid, t_stuid)) {
			history_pointer[count]->state = 0;
			s = 0;
		}
		++count;
	}
	if (s) {
		printf("\n\n\t未查询到符合条件记录!删除失败!");
		printf("\n\n    ----------菜单----------\n\n");
		printf("\t1.重新输入学号\n");
		printf("\t2.返回主菜单\n");
		printf("\t请选择所需功能并输入其前序号<1-2>.");
		char ch;
		while ((ch = getch()) && (ch < '1' || ch > '2')) {
		};
		if (ch == '1')
			delete_by_user();
	}
	else {
		printf("\n\t删除成功!\n");
		printf("\n\t请按任意键返回主菜单..");
		getch();
	}

}

/*以书为单位删除历史记录*/
void delete_by_isbn(void) {
	int count = 0, s = 1;
	printf("\n\n\t\t请输入需删除图书的ISBN: ");
	fgets(t_isbn, small, stdin);
	isfull(t_isbn, small);
	flush_stdin();
	printf("\t\t");
	while (count < count_history) {
		if (!strcmp(history_pointer[count]->isbn, t_isbn)) {
			history_pointer[count]->state = 0;
			s = 0;
		}
		++count;
	}
	if (s) {
		printf("\n\n\t未查询到符合条件记录!删除失败!");
		printf("\n\n    ----------菜单----------\n\n");
		printf("\t1.重新输入ISBN\n");
		printf("\t2.返回主菜单\n");
		printf("\t请选择所需功能并输入其前序号<1-2>.");
		char ch;
		while ((ch = getch()) && (ch < '1' || ch > '2')) {
		};
		if (ch == '1')
			delete_by_isbn();
	}
	else {
		printf("\n\t删除成功!\n");
		printf("\n\t请按任意键返回主菜单..");
		getch();
	}
}

/*以用户及图书删除历史记录*/
void delete_by_isbn_user(void) {
	int count = 0, s = 1;
	char isbn[small];
	printf("\n\n\t\t请输入需删除图书的ISBN: ");
	fgets(isbn, small, stdin);
	isfull(t_isbn, small);
	flush_stdin();
	printf("\t\t请输入对应用户学号: ");
	fgets(t_stuid, small, stdin);
	isfull(t_stuid, small);
	flush_stdin();
	printf("\t\t");
	while (count < count_history) {
		if (!strcmp(history_pointer[count]->isbn, isbn)
			&& !strcmp(history_pointer[count]->stuid, t_stuid)) {
			history_pointer[count]->state = 0;
			s = 0;
		}
		++count;
	}
	if (s) {
		printf("\n\n\t未查询到符合条件记录!删除失败!");
		printf("\n\n    ----------菜单----------\n\n");
		printf("\t1.重新输入学号和ISBN\n");
		printf("\t2.返回主菜单\n");
		printf("\t请选择所需功能并输入其前序号<1-2>.");
		char ch;
		while ((ch = getch()) && (ch < '1' || ch > '2')) {
		};
		if (ch == '1')
			delete_by_isbn_user();
	}
	else {
		printf("\n\t删除成功!\n");
		printf("\n\t请按任意键返回主菜单..");
		getch();
	}
}

/*显示更改菜单*/
char show_modify_menu(char modify_what) {
	char ch;
	printf("\n\n    ----------菜单----------\n\n");
	if (modify_what == about_user) {
		printf("\t1.修改年龄\n");
		printf("\t2.修改姓名\n");
		printf("\t3.修改学号\n");
		printf("\t4.修改密码\n");
		printf("\t5.修改学院\n");
		printf("\t6.修改专业\n");
		printf("\t7.修改联系方式\n");
		printf("\t8.修改权限(注:超级管理员)\n");
		printf("\t请选择所需功能并输入其前序号<1-8>.");
		while ((ch = getch()) && (ch < '1' || ch > '8'));
	}
	else if (modify_what == about_book) {
		printf("\t1.修改馆藏储量\n");
		printf("\t2.修改图书名称\n");
		printf("\t3.修改ISBN\n");
		printf("\t4.修改作者\n");
		printf("\t5.修改出版社\n");
		printf("\t6.修改出版时间\n");
		printf("\t7.修改价格\n");
		printf("\t请选择所需功能并输入其前序号<1-7>.");		
		while ((ch = getch()) && (ch < '1' || ch > '7'));
	}
	return ch;
}

/*更改图书/用户信息*/
void modify(char modify_what) {
	int index;
	char ch;
	if (modify_what == about_user) {
		if (user[current_index].identify[0] != superadmin) {
			index = current_index;
			system("cls");
			echo(index, about_user);
			
			modify_user(show_modify_menu(modify_what), index);
			printf("\n\t修改成功!\n");
			printf("\n\t请按任意键返回主菜单..");
			getch();
		}
		else {
			system("cls");
			do {
				system("cls");
				tip();
				printf("\n\n\t请输入学号: ");
				fgets(t_stuid, small, stdin);
				isfull(t_stuid, small);
				flush_stdin();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
			int count = 0;
			while (count < count_user) {
				if (!strcmp(user[count].stuid, t_stuid)) {
					index = count;
					echo(index, about_user);
					modify_user(show_modify_menu(modify_what), index);
					printf("\n\n\t修改成功!\n");
					printf("\n\t请按任意键返回主菜单..");
					getch();
					break;
				}
				++count;
			}
			if (count >= count_user) {

				printf("\n\n\t未查询到此读者!\n");
				printf("\n\n    ----------菜单----------\n\n");
				printf("\t1.重新输入学号\n");
				printf("\t2.放弃修改\n");
				printf("\t请选择所需功能并输入其前序号<1-2>.");
				char ch;
				while ((ch = getch()) && (ch < '1' || ch > '2')) {
				};
				if (ch == '1')
					modify(modify_what);
			}
		}
	}
	else if (modify_what == about_book) {
		do {
			system("cls");
			tip();
			printf("\n\n\t请输入ISBN: ");
			fgets(t_isbn, small, stdin);
			isfull(t_isbn, small);
			flush_stdin();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		int count = 0;
		while (count < count_book) {
			if (!strcmp(book[count].isbn, t_isbn)) {
				index = count;
				echo(index, about_book);
				modify_book(show_modify_menu(modify_what), index);
				printf("\n\n\t修改成功!\n");
				printf("\n\t请按任意键返回主菜单..");
				getch();
				break;
			}
			++count;
		}
		if (count >= count_book) {
			printf("\n\n\t未查询到此图书!\n");
			printf("\n\n    ----------菜单----------\n\n");
			printf("\t1.重新输入学号\n");
			printf("\t2.放弃修改\n");
			printf("\t请选择所需功能并输入其前序号<1-2>.");
			char ch;
			while ((ch = getch()) && (ch < '1' || ch > '2')) {
			};
			if (ch == '1')
				modify(modify_what);
		}
	}
}

/*更改用户信息*/
void modify_user(char serial,int index) {
	char ch;
	User *pointer = user_pointer[index];
	switch (serial) {
	case '1':
			do {
				printf("\n\n\t请输入读者年龄: ");
				fgets(pointer->age, 5, stdin);
				isfull(pointer->age, 5);
				flush_stdin();
				tip();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
			break;
	case '2':
			do {
				printf("\n\n\t请输入读者姓名: ");
				fgets(pointer->name, mid_b, stdin);
				isfull(pointer->name, mid_b);
				flush_stdin();
				tip();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
			break;
	case '3':
			do {
				printf("\n\n\t请输入读者学号: ");
				fgets(pointer->stuid, small, stdin);
				isfull(pointer->stuid, small);
				flush_stdin();
				tip();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
			break;
	case '4':
			do {
				printf("\n\n\t请输入读者密码: ");
				fgets(pointer->password, mid_b, stdin);
				isfull(pointer->password, mid_b);
				flush_stdin();
				tip();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
			break;
	case '5':
		do {
			printf("\n\n\t请输入读者所属学院: ");
			fgets(pointer->college, mid_s, stdin);
			isfull(pointer->college, mid_s);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '6':
		do {
			printf("\n\n\t请输入读者专业: ");
			fgets(pointer->major, small, stdin);
			isfull(pointer->major, small);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '7':
		do {
			printf("\n\n\t请输入读者联系方式: ");
			fgets(pointer->phone, small, stdin);
			isfull(pointer->phone, small);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '8':
		if(user[current_index].identify[0] == superadmin)
			do {
				printf("\n\n    ----------修改权限----------\n\n");
				printf("\t1.读者\n");
				printf("\t2.管理员\n");
				printf("\t3.超级管理员\n");
				printf("\t请选择所需功能并输入其前序号<1-3>.");
				while ((ch = getch()) && !(ch >= '1' && ch <= '3'));
				switch (ch) {
				case reader:	pointer->identify[0] = reader;		break;
				case admin:		pointer->identify[0] = admin;		break;
				case superadmin:pointer->identify[0] = superadmin;	break;
				default:											break;
				}
				putchar(ch);
				printf("\n\n\t修改成功!\n");
				tip();
				ch = check();
			} while (ch != 'y' && ch != 'Y');
		break;
	default:	
		break;
	}
}

/*更改图书信息*/
void modify_book(char serial, int index) {
	char ch;
	Book *pointer = book_pointer[index];
	
	switch (serial) {
	case '1':
		do {
			printf("\n\n\t请输入馆藏储量: ");
			fgets(pointer->storage, 5, stdin);
			isfull(pointer->storage, 5);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '2':
		do {
			printf("\n\n\t请输入图书名称: ");
			fgets(pointer->name, big, stdin);
			isfull(pointer->name, big);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '3':
		do {
			printf("\n\n\t请输入ISBN: ");
			fgets(pointer->isbn, small, stdin);
			isfull(pointer->isbn, small);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '4':
		do {
			printf("\n\n\t请输入作者: ");
			fgets(pointer->author, mid_b, stdin);
			isfull(pointer->author, mid_b);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '5':
		do {
			printf("\n\n\t请输入出版社: ");
			fgets(pointer->press, mid_s, stdin);
			isfull(pointer->press, mid_s);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '6':
		do {
			printf("\n\n\t请输入出版日期: ");
			fgets(pointer->pub_date, small, stdin);
			isfull(pointer->pub_date, small);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	case '7':
		do {
			printf("\n\n\t请输入价格: ");
			fgets(pointer->price, small, stdin);
			isfull(pointer->price, small);
			flush_stdin();
			tip();
			ch = check();
		} while (ch != 'y' && ch != 'Y');
		break;
	default:
		break;
	}
}

/*借书*/
void book_borrow(void) {
	system("cls");
	printf("\n\n\t\t请输入需借阅图书的ISBN: ");
	fgets(t_isbn, small, stdin);
	isfull(t_isbn, small);
	flush_stdin();
	int count = 0;
	while (count < count_book) {
		if (!strcmp(book[count].isbn, t_isbn)) {
			if (book[count].storage[0] > none) {
				book[count].storage[0] -= 1;
				add_history(&book[count]);
				printf("\n\t\t借书成功!\n\n\t\t");
				printf("请按任意键返回主菜单..");
				getch();
			}
			else {
				printf("\t\t该图书馆藏剩余量暂为0\n\n");
				printf("\t\t借书失败!\n\n\t\t");
				printf("请按任意键返回主菜单..");
				getch();
			}
			break;
		}
		++count;
	}
	if (count == count_book) {
		switch (isbn_not_find()) {
		case '1':	book_borrow();		break;
		case '2':						break;
		default:						break;
		}
	}
}

/*温馨提示*/
void tip(void) {
	printf("\n\n\t温馨提示:\n");
	printf("\t\t确认无误请输入<Y/y>,\n");
	printf("\t\t需修改请输入<N/n>.\n\n");
}
/*isbn not found menu*/
char isbn_not_find(void) {

	printf("\n\n\tISBN输入错误或暂未购进此书\n\n");
	printf("    ----------菜单----------\n\n");
	printf("\t1.重新输入ISBN\n");
	printf("\t2.返回主菜单\n");
	printf("\t请选择所需功能并输入其前序号<1-2>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '2')) {
	};
	return ch;
}

/*还书*/
void book_return(void) {
	char ch;
	do {
		system("cls");
		tip();
		printf("\n\t请输入需还图书ISBN: ");
		fgets(t_isbn, small, stdin);
		isfull(t_isbn, small);
		flush_stdin();
		ch = check();
	} while (ch != 'y' && ch != 'Y');
	int count = 0;
	while (count < count_book) {
		if (!strcmp(book[count].isbn, t_isbn)) {
			book[count].storage[0] += 1;
			break;
		}
	}
	if (count < count_book) {
		count = 0;
		while (count < count_history) {
			if (!strcmp(user[current_index].stuid, history[count].stuid)
				&& !strcmp(t_isbn, history[count].isbn)
				&& !strcmp("none\n", history[count].return_time)) {
				gettime(history[count].return_time);
				break;
			}
			++count;
		}
	}
	if (count == count_history) {
		printf("\n\n\t还书失败!");
		printf("\n\n    ----------菜单----------\n\n");
		printf("\t1.重新输入ISBN\n");
		printf("\t2.返回主菜单\n");
		printf("\t请选择所需功能并输入其前序号<1-2>.");
		while ((ch = getch()) && (ch < '1' || ch > '2')) {
		};
		if (ch == '1')
			book_return();
	}
	else {
		printf("\n\t还书完成!\n");
		printf("\n\t请按任意键返回主菜单..");
		getch();
	}
}

/*管理员授权*/
void admin_authoriza(void) {
	char ch;
	do {
		system("cls");
		printf("\n\n\t\t温馨提示\n");
		printf("\t\t\t确认无误请按<Y/y>\n");
		printf("\t\t\t需要修改请按<N/n>\n\n");
		printf("\t\t请输入读者学号: ");
		fgets(t_stuid, small, stdin);
		isfull(t_stuid, small);
		flush_stdin();
		ch = check();
	} while (ch != 'y' && ch != 'Y');
	int count = 0;
	extern int count_user;
	while (count < count_user) {
		if (!strcmp(user_pointer[count]->stuid, t_stuid)) {
			user_pointer[count]->identify[0] = admin;
			break;
		}
		++count;
	}
	if (count < count_user)
		printf("\n\t\t授权成功!\n\n\t\t");
	else
		printf("\n\t\t授权失败!\n\n\t\t");
	system("pause");
}

/*游客菜单,返回所需功能序号*/
char visitor_menu(void) {
	system("cls");
	printf("\n\n    ----------菜单----------\n\n");
	printf("\t1.查询图书信息\n");
	printf("\t2.返回重新登录\n");
	printf("\t3.退出程序\n\n");
	printf("\t请选择所需功能并输入其前序号<1-3>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '3')) {
	};
	return ch;
}

/*读者菜单,返回所需功能序号*/
char reader_menu(void) {
	system("cls");
	printf("\n\n    ----------菜单----------\n\n");
	printf("\t1.查询图书信息\n");
	printf("\t2.查询借阅历史\n");
	printf("\t3.借阅图书\n");
	printf("\t4.归还图书\n");
	printf("\t5.查询个人信息\n");
	printf("\t6.修改个人信息\n");
	printf("\t7.返回重新登录\n");
	printf("\t8.退出程序\n\n");
	printf("\t请选择所需功能并输入其前序号<1-8>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '8')) {
	};
	return ch;
}

/*管理员菜单,返回所需功能序号*/
char admin_menu(void) {
	system("cls");
	printf("\n\n    ----------菜单----------\n\n");
	printf("\t1.查询图书信息\n");
	printf("\t2.查询借阅历史\n");
	printf("\t3.借阅图书\n");
	printf("\t4.归还图书\n");
	printf("\t5.查询个人信息\n");
	printf("\t6.修改个人信息\n");
	printf("\t7.添加图书\n");
	printf("\t8.删除图书\n");
	printf("\t9.更改图书信息\n");
	printf("\ta.返回重新登录\n");
	printf("\tb.退出程序\n\n");
	printf("\t请选择所需功能并输入其前序号<1-9/a-b>.");
	char ch;
	while ((ch = getch()) && !((ch >= '1' && ch <= '9') || (ch >= 'a' && ch <= 'b') || (ch >= 'A' && ch <= 'B')) ) {
	};
	return tolower(ch);
}

/*超级管理员菜单,返回所需功能序号*/
char superadmin_menu(void) {
	system("cls");
	printf("\n\n    ----------菜单----------\n\n");
	printf("\t1.查询图书信息\n");
	printf("\t2.查询借阅历史\n");
	printf("\t3.借阅图书\n");
	printf("\t4.归还图书\n");
	printf("\t5.添加图书\n");
	printf("\t6.删除图书\n");
	printf("\t7.更改图书信息\n");
	printf("\t8.添加读者\n");
	printf("\t9.删除读者\n");
	printf("\ta.更改读者信息\n");
	printf("\tb.查询读者信息\n");
	printf("\tc.管理员授权\n");
	printf("\td.返回重新登录\n");
	printf("\te.退出程序\n\n");
	printf("\t请选择所需功能并输入其前序号<1-9/a-e>.");
	char ch;
	while ((ch = getch()) && 
	!((ch >= '1' && ch <= '9') || (ch >= 'a' && ch <= 'e') || (ch >= 'A' && ch <= 'E')) ){
	};
	return tolower(ch);
}
