#include <stdio.h>

void main ()
 {
   float value = 1.23456;

   printf ("%8.1f\n", value);
   printf ("%8.3f\n", value);
   printf ("%8.5f\n", value);
 }
