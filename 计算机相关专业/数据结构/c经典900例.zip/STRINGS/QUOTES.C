#include <stdio.h>

void main(void)
 {
   char string[] = "\"Stop!\", he said.";

   printf(string);
 }
