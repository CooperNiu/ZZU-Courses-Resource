#include <stdio.h>

void main ()
 {
   printf ("This is line one.\n");
   printf ("This is the second line.");
 }

