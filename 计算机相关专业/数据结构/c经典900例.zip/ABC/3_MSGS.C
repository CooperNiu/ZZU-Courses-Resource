#include <stdio.h>

void main ()
 {
   printf ("1001 ");
   printf ("C and C++ ");
   printf ("Tips!");
 }

