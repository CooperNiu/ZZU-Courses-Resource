#include <stdio.h>
#include <stdlib.h>

void main (void)
 {
   printf("The absolute value of %d is %d\n", 5, abs(5));
   printf("The absolute value of %d is %d\n", 0, abs(0));
   printf("The absolute value of %d is %d\n", -5, abs(-5));
 }
