#include <stdio.h>
#include <dos.h>

void main(void)
 {
   printf("Previous extended Ctrl-Break status %s\n",
    (getcbrk()) ? "On": "Off");

   setcbrk(0);  /* Turn if off*/
    }


