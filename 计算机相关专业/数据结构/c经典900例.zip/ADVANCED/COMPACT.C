#include <stdio.h>

void main(void)
 {
   int a = 1, b, c, d;

   switch (a) {
    case 1: a = 5;
            b = 6;
            c = 7;
            d = 8;
            break;
    case 2: b = 6;
            c = 7;
            d = 8;
            break;
    };
 }

