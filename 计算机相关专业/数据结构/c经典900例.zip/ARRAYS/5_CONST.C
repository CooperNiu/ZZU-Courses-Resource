#include <stdio.h>

#define ARRAY_SIZE 5

void main(void)
 {
   int values[ARRAY_SIZE] = {80, 70, 90, 85, 80};
   int i;

   for (i = 0; i < ARRAY_SIZE; i++)
     printf("values[%d] %d\n", i, values[i]);
 }
