#include <stdio.h>

void main ()
 {
   printf("The file %s is under Beta testing\n", __FILE__);
 }
