#include <stdio.h>

int get_maximum(int, int);

void main(void)
 {
   int result;

   result = get_maximum(100, 200);

   printf("The larger value is %d\n", result);
 }
