#include <conio.h>

void main(void)
 {
   clrscr();

   gotoxy(1, 5);
   cprintf("Output at row 5 column 1\n");

   gotoxy(20, 10);
   cprintf("Output at row 10 column 20\n");
 }


