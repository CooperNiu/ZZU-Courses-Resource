#include <stdio.h>

void main()
 {
   int first_count;
   int second_count;

   printf("Jamsa%n's 1001 C & C++ Tips%n\n", &first_count,
     &second_count);

   printf("First count %d Second count %d\n", first_count,
     second_count);
 }

