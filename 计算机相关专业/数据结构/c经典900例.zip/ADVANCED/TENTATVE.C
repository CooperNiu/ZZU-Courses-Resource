#include <stdio.h>

int value;

void main(void)
 {
   printf("%d\n", value);
 }


int value = 1001;

