#include <stdio.h>
#include <stdlib.h>

void main (void)
 {
   printf("Maximum of %f and %f is %f\n", 
     10.0, 25.0, max(10.0, 25.0));
   printf("Minimum of %f and %f is %f\n", 
     10.0, 25.0, min(10.0, 25.0));
 }
