#include <stdio.h>
#include <math.h>

void main (void)
 {
   printf("cosine of pi/2 is %6.4f\n", cos(3.14159/2.0));
   printf("cosine of pi is %6.4f\n", cos(3.14159));
 }
