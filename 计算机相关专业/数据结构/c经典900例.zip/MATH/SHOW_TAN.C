#include <stdio.h>
#include <math.h>

void main(void)
 {
   double pi = 3.14159265;

   printf("Tangent of pi is %f\n", tan(pi));
   printf("Tangent of pi/4 is %f\n", tan(pi / 4.0));
 }
