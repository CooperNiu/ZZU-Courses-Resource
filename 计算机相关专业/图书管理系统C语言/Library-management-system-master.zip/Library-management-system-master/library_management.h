#ifndef __LIBMNG_H__
#define __LIBMNG_H__

#define small			20
#define mid_s			50
#define mid_b			100
#define big				200
#define MAXN			1000	/*用户最大数量*/
#define none			'0'		/*图书库存为空*/
#define visitor			'0'		/*游客权限*/
#define reader			'1'		/*普通读者权限*/
#define admin			'2'		/*图书管理员权限*/
#define superadmin		'3'		/*超级图书管理员权限*/
#define quit			'q'


#define about_user		'5'		/*函数参数*/
#define about_book		'6'		/*函数参数*/
#define about_history	'7'		/*函数参数*/

/*	*	*	*	*	*	*	*	*	*	*	*
**											*
**	三个结构体中state变量作用:				*
**	最后修改完成后,用于标示原有信息是否被删除;	*
**	若已删除则不再写入文件;					*
**											*
**	*	*	*	*	*	*	*	*	*	*	*/

/*用户信息*/
typedef struct users {
	char age[5];
	char name[mid_b];
	char stuid[small];
	char password[mid_b];
	char college[mid_s];
	char major[small];
	char phone[small];
	char identify[5];				
	int  state;					
}User;

/*图书信息*/	
typedef struct book_info {
	char storage[5];
	char name[big];
	char isbn[small];
	char author[mid_b];
	char press[mid_s];
	char pub_date[small];	
	char price[small];
	int  state;
}Book;

/*借阅历史*/
typedef struct history {
	char stuid[small];
	char name[big];
	char isbn[small];
	char author[mid_b];
	char pub_date[small];
	char borrow_time[small];
	char return_time[small];
	int  state;
}History;


/*
**	判断数组是否已满
**	若已满(最后不为“\n\0”) 则重置这两位
**	否则将‘\n’放回输入缓冲区
*/
void isfull(char *pointer, int size);

/*刷新标准输入缓冲区*/
void flush_stdin(void);


/*
**	读取文件信息初始化三个结构体数组
**	User user[MAXN];
**	Book book[MAXN];
**	History history[MAXN*MAXN];
**
*/
void initial(void);

/*将修改过的信息一并写入文件保存*/
void save(void);

/*生成初始界面;	*/
void welcome(void);

/*
** 用户登录
**
** 不同用户权限不同,功能菜单不同;
** 此函数用于确定用户权限.
** 并返回标志该用户权限的字符;
**	
*/
char authentication(void);

/*游客方式访问*/
void visitors(void);

/*读者方式访问*/
void readers(void);

/*管理员方式访问*/
void admins(void);

/*超级管理员方式访问*/
void superadmins(void);



/*
**
**	函数功能:	查询并打印数据(可查询三个不同的结构体)
**  函数参数:    单个字符参数,char search_what
**				用于说明查询的是什么数据
**				例如 若实参为 s_user, 代表查询的是用户信息;
*/
void search(char search_what);


/*回显用户/图书/历史记录信息*/
void echo(int index, char echo_what);

/*查询指定读者记录*/
void sea_his_by_user(void);


/*查询指定图书记录*/
void sea_his_by_book(void);


/*查询指定读者对指定图书的记录*/
void sea_his_by_user_book(void);

/*
**	函数功能:	添加用户/图书/历史记录
**	函数参数:	说明添加的是什么
*/
void add(char add_what);

/*添加用户*/
void add_user(void);

/*添加用户信息*/
void add_user_info(void);

/*添加图书*/
void add_book(void);

/*添加图书信息*/
void add_book_info(void);

/*添加历史*/
void add_history(Book *pointer);

/*检查输入是否符合要求*/
char check(void);

/*获取当前时间并以1970-01-01形式储存在ti所指数组中*/
void gettime(char *ti);

/*
**	函数功能:	删除用户/图书/历史记录
**	函数参数:	说明删除的是什么
*/
void delete(char delete_what);

/*删除记录菜单*/
char delete_menu(void);

/*以用户为单位删除历史记录*/
void delete_by_user(void);

/*以书为单位删除历史记录*/
void delete_by_isbn(void);

/*以用户及图书删除历史记录*/
void delete_by_isbn_user(void);

/*更改图书/用户信息*/
void modify(char modify_what);

/*显示更改菜单*/
char show_modify_menu(char modify_what);

/*更改用户信息*/
void modify_user(char serial, int index);

/*更改图书信息*/
void modify_book(char serial, int index);

/*借书*/
void book_borrow(void);

/*isbn not found menu*/
char isbn_not_find(void);

/*还书*/
void book_return(void);

/*管理员授权*/
void admin_authoriza(void);

/*游客菜单,返回所需功能序号*/
char visitor_menu(void);

/*读者菜单,返回所需功能序号*/
char reader_menu(void);

/*管理员菜单,返回所需功能序号*/
char admin_menu(void);

/*超级管理员菜单,返回所需功能序号*/
char superadmin_menu(void);

/*游客方式或用户登录*/
char visitor_or_login(void);

/*登录失败提示信息*/
char login_failed_menu(void);

/*登录提示信息*/
void login_menu(void);

/*温馨提示*/
void tip(void);

#endif
