#include <stdio.h>
#include <dos.h>

void main(void)
 {
   printf("About to sleep for 5 seconds\n");
   sleep(5);
   printf("Awake\n");
 }

