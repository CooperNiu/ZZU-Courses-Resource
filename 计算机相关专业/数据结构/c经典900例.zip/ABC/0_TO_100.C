#include <stdio.h>

void main ()
 {
   int value = 0;

   while (value <= 100)
     {
       printf("%d\n", value);
       value++;
     }
 }

