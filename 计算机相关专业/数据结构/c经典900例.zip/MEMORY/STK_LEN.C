#include <stdio.h>
#include <dos.h>

void main(void)
 {
   printf("The current stack size %d bytes\n", _stklen);
 }
 
