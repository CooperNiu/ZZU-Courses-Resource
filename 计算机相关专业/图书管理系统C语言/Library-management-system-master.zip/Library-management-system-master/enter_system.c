#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include"library_management.h"
#pragma warning (disable : 4996)

extern User user[MAXN] ,*user_pointer[MAXN];
extern Book book[MAXN] ,*book_pointer[MAXN];
extern History history[MAXN*MAXN] ,*history_pointer[MAXN*MAXN];
extern int state;
extern int current_index;
char t_stuid[small];
char t_password[mid_b];

/*生成初始界面;*/
void welcome(void) {
	printf("\n\n\n\n\n");
	printf("\t\t  * * * * * * * * * * * * * * * * * * * * * *\n");
	printf("\t\t  *                                         *\n");
	printf("\t\t  *                                         *\n");
	printf("\t\t  *        library management system        *\n");
	printf("\t\t  *                                         *\n");
	printf("\t\t  *                                         *\n");
	printf("\t\t  * * * * * * * * * * * * * * * * * * * * * *\n\n");
	printf("\t\t\t         press any key to continue..");
	getch();
}

/*
**		用户登录
**
**		不同用户权限不同,功能菜单不同;
**		此函数用于确定用户权限,
**		并返回标志该用户权限的字符;
**
*/
char authentication(void) {
	char ch;
	ch = visitor_or_login();
	if (ch != reader)
		return ch;
	login_menu();	
	printf("\t\t学  号:  ");
	fgets(t_stuid, small, stdin);
	isfull(t_stuid, small);
	flush_stdin();
	printf("\t\t密  码:  ");
	fgets(t_password, mid_b, stdin);
	isfull(t_password, mid_b);
	flush_stdin();

	int count = 0;
	extern int count_user;
	while (count < count_user) {
		if (!strcmp(user_pointer[count]->stuid, t_stuid) 
			&& !strcmp(user_pointer[count]->password, t_password)) {
			current_index = count;
			return user_pointer[count]->identify[0];
		}
		++count;
	}
	switch (login_failed_menu()) {
	case '1':	return authentication();	
	case '2':	return quit;				
	default:	return quit;
	}
}
/*登录失败提示信息*/
char login_failed_menu(void) {
	system("cls");
	printf("\n\n\n\t\t学号或密码错误!\n");
	printf("\t\t1.重新登录\n");
	printf("\t\t2.退出程序\n");
	printf("\t\t请选择所需功能并输入其前序号<1-2>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '2')) {
	};
	return ch;
}

/*游客方式或用户登录*/
char visitor_or_login(void) {
	system("cls");
	printf("\n\n\t\t温馨提示:\n");
	printf("\t\t\t1.以游客方式登录\n");
	printf("\t\t\t2.用户登录\n");
	printf("\t\t\t3.退出程序\n");
	printf("\t\t请选择所需功能并输入其前序号<1-3>.");
	char ch;
	while ((ch = getch()) && (ch < '1' || ch > '3'));
	switch (ch) {
	case '1':	return visitor;
	case '2':	return reader;
	case '3':	return quit;
	default:	return quit;
	}
}


/*登录提示信息*/
void login_menu(void) {
	system("cls");
	printf("\n\n\t     ----------请依提示输入学号及密码----------\n\n");	
}
