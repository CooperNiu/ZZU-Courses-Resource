#include <stdio.h>

void main ()
 {
   // printf ("This line does not appear");

   /* This is a comment

      printf ("This line does not appear either");

   */
 }

