#include <stdio.h>

void main ()
 {
   printf("The letter is %c\n", 'A');
   printf("The letter is %c\n", 65);
 }

