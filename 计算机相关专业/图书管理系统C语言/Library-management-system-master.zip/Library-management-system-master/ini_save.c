#include<stdio.h>
#include<stdlib.h>
#include"library_management.h"
#pragma warning(disable : 4996)

extern User user[MAXN], *user_pointer[MAXN];
extern Book book[MAXN], *book_pointer[MAXN];
extern History history[MAXN*MAXN], *history_pointer[MAXN];
char temp[big];

/*
**	读取文件信息,初始化三个结构体数组
**	User user[MAXN];				用户信息
**	Book book[MAXN];				图书信息
**	History history[MAXN*MAXN];		历史记录
**
*/

void initial(void) {
	FILE *fp1, *fp2, *fp3;
	fp1 = fopen("user_info.txt", "r");
	fp2 = fopen("book_info.txt", "r");
	fp3 = fopen("history_info.txt", "r");
	if (fp1 != NULL && fp2 != NULL && fp3 != NULL) {
		extern int state;
		state = 1;
		extern int count_user;
		while (fscanf(fp1,"%s\n",temp) != EOF) {
			sprintf(user[count_user].age, "%s\n", temp);
			fgets(user[count_user].name, mid_b, fp1);
			fgets(user[count_user].stuid, small, fp1);
			fgets(user[count_user].password, mid_b, fp1);
			fgets(user[count_user].college, mid_s, fp1);
			fgets(user[count_user].major, small, fp1);
			fgets(user[count_user].phone, small, fp1);
			fgets(user[count_user].identify, 5, fp1);
			user[count_user].state = 1;
			++count_user;
		}
		for (int i = 0; i < MAXN; ++i) 
			user_pointer[i] = &user[i];
		
		extern int count_book;
		while (fscanf(fp2,"%s\n",temp) != EOF) {
			sprintf(book[count_book].storage, "%s\n", temp);
			fgets(book[count_book].name, big, fp2);
			fgets(book[count_book].isbn, small, fp2);
			fgets(book[count_book].author, mid_b, fp2);
			fgets(book[count_book].press, mid_s, fp2);
			fgets(book[count_book].pub_date, small, fp2);
			fgets(book[count_book].price, small, fp2);
			book[count_book].state = 1;

	/*
			fputs(book[count_book].storage, stdout);
			fputs(book[count_book].name, stdout);
			fputs(book[count_book].isbn, stdout);
			fputs(book[count_book].author, stdout);
			fputs(book[count_book].press, stdout);
			fputs(book[count_book].pub_date, stdout);
			fputs(book[count_book].price, stdout);
			*/
			
			++count_book;
		
		}
		for (int i = 0; i < MAXN; ++i)
			book_pointer[i] = &book[i];

		extern int count_history;
		while (fscanf(fp3, "%s\n", temp) != EOF) {
			sprintf(history[count_history].stuid, "%s\n", temp);
			fgets(history[count_history].name, big, fp3);
			fgets(history[count_history].isbn, small, fp3);
			fgets(history[count_history].author, mid_b, fp3);
			fgets(history[count_history].pub_date, small, fp3);
			fgets(history[count_history].borrow_time, small, fp3);
			fgets(history[count_history].return_time, small, fp3);
			history[count_history].state = 1;
			++count_history;
		}
		for (int i = 0; i < MAXN; ++i)
			history_pointer[i] = &history[i];
	}
	else {
		printf("\n\n\n\n\n\t\t\tFailed to open file!\n\n\t\t\t");
		system("pause");
		exit(EXIT_FAILURE);
	}
	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
}


/*将修改过的信息一并写入文件保存*/
void save(void) {
	FILE *fp1, *fp2, *fp3;
	fp1 = fopen("user_info.txt", "w");
	fp2 = fopen("book_info.txt", "w");
	fp3 = fopen("history_info.txt", "w");
	if (fp1 != NULL && fp2 != NULL && fp3 != NULL) {
		int count = 0;
		extern int count_user;
		while (count < count_user && user[count].state == 1 ) {
			fputs(user[count].age,fp1);
			fputs(user[count].name, fp1);
			fputs(user[count].stuid, fp1);
			fputs(user[count].password, fp1);
			fputs(user[count].college, fp1);
			fputs(user[count].major, fp1);
			fputs(user[count].phone, fp1);
			fputs(user[count].identify, fp1);
			++count;
		}

		count = 0;
		extern int count_book;
		while (count < count_book && book[count].state == 1 ){
			fputs(book[count].storage,fp2);
			fputs(book[count].name, fp2);
			fputs(book[count].isbn, fp2);
			fputs(book[count].author, fp2);
			fputs(book[count].press, fp2);
			fputs(book[count].pub_date, fp2);
			fputs(book[count].price, fp2);
			++count;
		}

		count = 0;
		extern int count_history;
		while (count < count_history && history[count].state == 1 ){
			fputs(history[count].stuid, fp3);
			fputs(history[count].name, fp3);
			fputs(history[count].isbn, fp3);
			fputs(history[count].author, fp3);
			fputs(history[count].pub_date, fp3);
			fputs(history[count].borrow_time, fp3);
			fputs(history[count].return_time, fp3);
			++count;
		}
	}
	else {
		printf("\n\n\n\n\n\t\t\tFailed!\n\n\t\t\t");
		system("pause");
		exit(EXIT_FAILURE);
	}
	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
}
