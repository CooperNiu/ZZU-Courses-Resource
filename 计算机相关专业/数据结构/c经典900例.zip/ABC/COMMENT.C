/* Program: COMMENT.C*/
/* Written by: Kris Jamsa*/
/* Date written: 06-30-93*/

/* Purpose: Illustrates the use of comments in a C program.*/

#include <stdio.h>

void main ()
 {
   printf ("1001 C & C++ Tips!");  /* Display a message*/
 }


