#include <stdio.h>
#include <string.h>

void main(void)
 { 
   printf(strlwr("1001 C/C++ Tips!\n"));
   printf(strupr("1001 C/C++ Tips!\n"));
 }
